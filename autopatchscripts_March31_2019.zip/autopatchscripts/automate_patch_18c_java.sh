#!/bin/ksh
. /oracle/oraxxx/home/.profile
cd /oracle/oraxxx/home/auto_patch
./DBShut.sh >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
rc=$?
if [ ${rc} -eq 0 ];then
echo "shutdown database pass" >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
else
echo "shutdown failed" >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
./notify_mail_dbag_patch_fail.sh
exit 1
fi
//directory of downloaded patch 
cd /22738582/22674709 
$ORACLE_HOME/OPatch/opatch prereq CheckConflictAgainstOHWithDetail -ph ./ -invPtrLoc /oracle/oraxxx/oraInst.loc
if [ ${rc} -eq 0 ];then
echo "patch check up succeeded" >>patch_temp_log.log >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
else
echo "patch check up failed" >>patch_temp_log.log >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
./notify_mail_dbag_patch_fail.sh
exit 1 
fi
$ORACLE_HOME/OPatch/opatch apply -silent -ocmrf /oracle/oraxxx/home/auto_patch/ocm_dce.rsp >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
rc=$?
if [ ${rc} -eq 0 ];then
echo "patch applied successfully" >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
else
echo "patch apply failed"  >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
./notify_mail_dbag_patch_fail.sh
exit 1
fi
cd /oracle/oraxxx/home/auto_patch
./DBStart_upgrade.sh  >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
cd $home/OPatch
./datapatch -verbose   >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
cd /oracle/oraxxx/home/auto_patch 
./DBShut.sh  >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
if [ ${rc} -eq 0 ];then
echo "database shutdown successfull" >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
else
echo "database shutdown failed" >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
./notify_mail_dbag_patch_fail.sh
exit 1
fi
./DBStart.sh  >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
if [ ${rc} -eq 0 ];then
echo "database start up successfull" >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
else
echo "database start up failed" >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
./notify_mail_dbag_patch_fail.sh
exit 1
fi
cd /oracle/oraxxx/home/auto_patch
./after_java_patch_info.sh  >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
./notify_mail_dbag.sh  >>/oracle/oraxxx/home/auto_patch/patch_temp_log.log
