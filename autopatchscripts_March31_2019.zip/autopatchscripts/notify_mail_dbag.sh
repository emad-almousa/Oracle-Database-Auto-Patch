#!/bin/ksh
DB_STATUS_PATCH=/export/oraxxx/auto_patch/notify.log; export DB_STATUS_PATCH
TODAY_DATE=`date +%m-%d-%y`; export TODAY_DATE
mail_list=EMADO@Exchange.Contoso.com; export mail_list
log_file=patch_temp_log.log; export log_file
cd /export/oraxxx/auto_patch/ 
uuencode $log_file $log_file |mailx -s "Patching oraxxx is successful,please check Database XXX  patch log attached" EMADO@Exchange.Contoso.com





