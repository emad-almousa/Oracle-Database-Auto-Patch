DB_STATUS_PATCH=/export/oraxxx/auto_patch//notify.log; export DB_STATUS_PATCH
TODAY_DATE=`date +%m-%d-%y`; export TODAY_DATE
mail_list=EMADO@Exchange.Contoso.com; export mail_list
echo "********************************************************************************" >> $DB_STATUS_PATCH
echo "***  oraxxx ORACLE Database Patch,  $TODAY_DATE                            ***" >> $DB_STATUS_PATCH
echo "********************************************************************************" >> $DB_STATUS_PATCH
echo "                                                                                " >> $DB_STATUS_PATCH
echo "                                                                                " >> $DB_STATUS_PATCH
echo "oraxxx Database Patched Successfully, please connect and check your application    " >> $DB_STATUS_PATCH
#
mailx -s "oraxxx Database has been successfully patched on $TODAY_DATE " $mail_list < $DB_STATUS_PATCH
