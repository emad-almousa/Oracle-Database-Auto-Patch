#!/bin/ksh

. /oracle/oraxxx/home/.profile
sqlplus / as sysdba << EOF
@$ORACLE_HOME/rdbms/admin/utlrp.sql
EXIT;
