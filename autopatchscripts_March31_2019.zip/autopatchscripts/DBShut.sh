#!/bin/ksh
. /oracle/oraxxx/home/.profile
# shtudown Listener
lsnrctl stop LISTENER_XXX  

# shtudown Database
sqlplus / as sysdba << EOF
SHUTDOWN IMMEDIATE;
EXIT;
