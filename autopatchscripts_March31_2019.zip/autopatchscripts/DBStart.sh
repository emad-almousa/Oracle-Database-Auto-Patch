#!/bin/ksh
. /oracle/oraxxx/home/.profile
# Start Listener
lsnrctl start listener_XXX

# Start Database
sqlplus / as sysdba << EOF
STARTUP;
EXIT;
