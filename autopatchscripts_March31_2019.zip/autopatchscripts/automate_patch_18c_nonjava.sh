#!/bin/ksh

. /oracle/oraxxx/oracle_home/.profile
##inventory file should be Local
cd /export/oraxxx/auto_patch/
./pre_patch_info.sh >>/export/oraxxx/auto_patch/patch_temp_log.log
./DBShut.sh >>/export/oraxxx/auto_patch/patch_temp_log.log
rc=$?
if [ ${rc} -eq 0 ];then
echo "shutdown database pass" >>/export/oraxxx/auto_patch/patch_temp_log.log
else
echo "shutdown failed"  >>/export/oraxxx/auto_patch/patch_temp_log.log
cd /export/oraxxx/auto_patch
./notify_mail_dbag_patch_fail.sh
exit 1
fi
//directory of downloaded patch 
cd /export/oraxxx/patch/18.5_non_java/28822489
/$ORACLE_HOME/OPatch/opatch  prereq CheckConflictAgainstOHWithDetail -ph ./ -invPtrLoc /etc/oraInst.loc  >>/export/oraxxx/auto_patch/patch_temp_log.log
rc=$?
if [ ${rc} -eq 0 ];then
echo "patch check up succeeded" >>/export/oraxxx/auto_patch/patch_temp_log.log
else
echo "patch check up failed" >>/export/oraxxx/auto_patch/patch_temp_log.log
cd /oracle/oraxxx/auto_patch/
./notify_mail_dbag_patch_fail.sh
exit 1
fi
/$ORACLE_HOME/OPatch/opatch apply -silent -ocmrf /export/oraxxx/auto_patch/ocm_dce.rsp  >>/export/oraxxx/auto_patch/patch_temp_log.log
rc=$?
if [ ${rc} -eq 0 ];then
echo "patch applied successfully"  >>/export/oraxxx/auto_patch/patch_temp_log.log
else
echo "patch apply failed" >>/export/oraxxx/auto_patch/patch_temp_log.log
cd /export/oraxxx/auto_patch/
./notify_mail_dbag_patch_fail.sh
exit 1
fi
cd /export/oraxxx/auto_patch/
./DBStart.sh   >>/export/oraxxx/auto_patch/patch_temp_log.log
if [ ${rc} -eq 0 ];then
echo "database start up successfull"  >>/export/oraxxx/auto_patch/patch_temp_log.log
else
echo "database start up failed"  >>/export/oraxxx/auto_patch/patch_temp_log.log
cd /export/oraxxx/auto_patch/
./notify_mail_dbag_patch_fail.sh
exit 1
fi
cd $ORACLE_HOME/OPatch
./datapatch -verbose >>/export/oraxxx/auto_patch/patch_temp_log.log
if [ ${rc} -eq 0 ];then
echo "datapatch executed successfully" >>/export/oraxxx/auto_patch/patch_temp_log.log
else
echo "datapatch execution failed" >>/export/oraxxx/auto_patch/patch_temp_log.log
cd /export/oraxxx/auto_patch/
./notify_mail_dbag_patch_fail.sh
exit 1
fi
cd /export/oraxxx/auto_patch/
./after_patch_info.sh  >>/export/oraxxx/auto_patch/patch_temp_log.log
./notify_mail_users.sh

