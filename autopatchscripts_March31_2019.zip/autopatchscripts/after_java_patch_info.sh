#!/bin/ksh
. /oraclex/oradbq14/oracle_home/.profile
# gathering information after patching
sqlplus / as sysdba << EOF
set pages 300
set lines 250
col owner for a17;
col object_name for a35;
col object_type for a20;
col action for a15;
col comments for a40;
col comp_name for a40;
col version for a15;

spool /oraclex/oradbq14/oracle_home/auto_patch/patch_logfiles/after_apply_JAVA_APRIL_2016_12c_PSU.log
SELECT NAME FROM V$DATABASE;
SELECT * from V$VERSION;
select patch_id, version, status, description, action_time from dba_registry_sqlpatch order by 1;
select COMP_ID,COMP_NAME,VERSION,STATUS,MODIFIED from dba_registry;
select count(*) from dba_objects where  status = 'INVALID';
select owner, count(*) from dba_objects where status <>'VALID' group by owner order by 1;
Select owner, object_type, object_name
from dba_objects where status <>'VALID' order by 1,2,3;
spool off
EXIT;
