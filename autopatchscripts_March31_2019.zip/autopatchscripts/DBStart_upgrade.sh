#!/bin/ksh
. /oracle/oraxxx/home/.profile
# Start Database
sqlplus / as sysdba << EOF
STARTUP UPGRADE;
EXIT;
