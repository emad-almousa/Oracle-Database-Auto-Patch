#!/bin/ksh
. /oraclex/oraxxx/home/.profile
# gathering information after patching
sqlplus / as sysdba << EOF
set pages 300
set lines 250 
col owner for a17;
col object_name for a35;
col object_type for a20;
col action for a15;
col comments for a40;
col comp_name for a40;
col version for a15;

spool /export/oradbu01/auto_patch/auto_patch/patch_logfiles/after_apply_JAN_2019_18c_PSU.log
SELECT NAME FROM \V$DATABASE;
SELECT * from V\$VERSION;
select patch_id, action, status, description, action_time from dba_registry_sqlpatch ;
select count(*) from dba_objects where  status = 'INVALID';
select owner, count(*) from dba_objects where status <>'VALID' group by owner order by 1; 
Select owner, object_type, object_name 
from dba_objects where status <>'VALID' order by 1,2,3;  
spool off
EXIT;
